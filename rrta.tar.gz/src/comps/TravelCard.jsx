export const TravelCart = ({ travel }) => {
  return (
    <li>
      <h3>{travel.category}</h3>
      <h3>{travel.country}</h3>
      <p>{travel.city}</p>
      <p>{travel.rating}</p>
      <p>{travel.duration}</p>
      <p>{travel.price}</p>
    </li>
  )
}